def calculate_area():

 if not isinstance(h, float):
      try:
        h = float(h)
      except:
          print ("Arguments must be numbers!")
          return 0
 if not isinstance(b, float):
        try:
         b = float(b)
        except:
          print ("Arguments must be numbers!")
          return 0
 if h > 0 and b > 0:
        return (h*b)/2
 else:
        print("Cannot supply negative values as argument!")


if __name__ == "__main__":
    h = input("Enter hight of triangle: ")
    b = input("Enter base of triangle: ")
    print("Area of triangle: " + str(calculate_area()))            